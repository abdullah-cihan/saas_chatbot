# SaaS Chatbot Platform

This is the initial project structure.
